# v2.0.2
## 02/19/2016

1. [](#bugfix)
    * Change demo link

# v2.0.1
## 02/18/2016

1. [](#bugfix)
    * Fix sidebar

# v2.0.0
## 02/18/2016

1. [](#bugfix)
    * Change the template structures

# v1.1.2
## 02/15/2016

1. [](#bugfix)
    * Fix bower and npm

# v1.1.1
## 02/13/2016

1. [](#new)
    * Fix links

# v1.1.0
## 02/12/2016

1. [](#new)
    * Added logic to include site.menu items in modular pages
    * Added a configurable lang field for HTML tag
    * Added a `bottom` JS output call
1. [](#improved)
    * Updated to FontAwesome 4.4.0
1. [](#bugfix)
    * Fixed extra `/` in some tag URLs
    * Better support for PECL Yaml parser
    * Fixes for blog page blueprint

# v1.0.0
## 02/07/2016

1. [](#new)
    * Added logic to include site.menu items in modular pages
1. [](#improved)
    * Removed unused `<p>` tags
