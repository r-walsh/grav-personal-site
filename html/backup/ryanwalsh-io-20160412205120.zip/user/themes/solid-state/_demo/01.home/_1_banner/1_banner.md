---
icon: fa-diamond
---
##This is Solid State
Another free + fully responsive site template by [HTML5 UP](http://html5up.net)