---
title: About
class: about
profile: true
---

* Co-Lead Instructor at [DevMountain](https://devmounta.in/) Dallas.
* Burgeoning React/React Native fanboy.
* Sporadic (at best) blog poster.