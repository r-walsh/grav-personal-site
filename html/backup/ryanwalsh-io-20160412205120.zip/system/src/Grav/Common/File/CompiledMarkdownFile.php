<?php
namespace Grav\Common\File;

use RocketTheme\Toolbox\File\MarkdownFile;

class CompiledMarkdownFile extends MarkdownFile
{
    use CompiledFile;
}
